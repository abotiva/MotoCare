import { useState } from 'react'
import { 
  Plus, Wrench, AlertTriangle, CheckCircle, 
  Clock, Gauge, FileText, Camera
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'

const bikes = [
  {
    id: 1,
    brand: 'Honda',
    model: 'CB500F',
    year: 2022,
    plate: 'ABC-123',
    mileage: 15420,
    color: 'Rojo',
    image: '/hero-motorcycle.jpg',
    nextService: { km: 16000, days: 15 },
    health: 92,
    services: [
      { id: 1, type: 'Cambio de aceite', date: '2024-11-15', km: 15000, status: 'completed' },
      { id: 2, type: 'Revisión general', date: '2024-10-01', km: 14000, status: 'completed' },
      { id: 3, type: 'Cambio de frenos', date: '2024-08-20', km: 12000, status: 'completed' },
    ],
    upcomingServices: [
      { id: 4, type: 'Cambio de aceite', dueKm: 16000, dueDate: '2025-02-20', status: 'pending' },
      { id: 5, type: 'Revisión de cadena', dueKm: 16500, dueDate: '2025-03-01', status: 'pending' },
    ]
  },
  {
    id: 2,
    brand: 'Yamaha',
    model: 'MT-03',
    year: 2021,
    plate: 'XYZ-789',
    mileage: 28500,
    color: 'Azul',
    image: '/feature-marketplace.jpg',
    nextService: { km: 30000, days: 45 },
    health: 85,
    services: [
      { id: 1, type: 'Cambio de aceite', date: '2024-12-01', km: 28000, status: 'completed' },
      { id: 2, type: 'Cambio de llantas', date: '2024-09-15', km: 25000, status: 'completed' },
    ],
    upcomingServices: [
      { id: 3, type: 'Revisión general', dueKm: 30000, dueDate: '2025-03-15', status: 'pending' },
      { id: 4, type: 'Cambio de bujías', dueKm: 32000, dueDate: '2025-04-01', status: 'pending' },
    ]
  }
]

export function MyBikes() {
  const [selectedBike, setSelectedBike] = useState(bikes[0])
  const [showAddBike, setShowAddBike] = useState(false)

  return (
    <div className="max-w-6xl mx-auto p-4 lg:p-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">Mis Motos</h1>
          <p className="text-gray-400">Gestiona el mantenimiento y hoja de vida de tus motos</p>
        </div>
        <Button 
          className="bg-moto-orange hover:bg-moto-orange-dark"
          onClick={() => setShowAddBike(true)}
        >
          <Plus className="w-5 h-5 mr-2" />
          Agregar Moto
        </Button>
      </div>

      {/* Bikes Selector */}
      <div className="flex gap-4 overflow-x-auto pb-4 mb-6 scrollbar-hide">
        {bikes.map((bike) => (
          <button
            key={bike.id}
            onClick={() => setSelectedBike(bike)}
            className={`flex-shrink-0 flex items-center gap-3 p-3 rounded-xl border transition-all ${
              selectedBike.id === bike.id
                ? 'bg-moto-orange/20 border-moto-orange'
                : 'bg-moto-gray border-white/5 hover:border-white/20'
            }`}
          >
            <div className="w-16 h-16 rounded-lg overflow-hidden">
              <img src={bike.image} alt={`${bike.brand} ${bike.model}`} className="w-full h-full object-cover" />
            </div>
            <div className="text-left">
              <p className="font-semibold">{bike.brand} {bike.model}</p>
              <p className="text-sm text-gray-400">{bike.year} · {bike.plate}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Bike Details */}
      {selectedBike && (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Info Card */}
          <Card className="lg:col-span-2 bg-moto-gray border-white/5 overflow-hidden">
            <div className="relative h-64 overflow-hidden">
              <img 
                src={selectedBike.image} 
                alt={`${selectedBike.brand} ${selectedBike.model}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-moto-gray via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-end justify-between">
                  <div>
                    <h2 className="text-3xl font-bold">{selectedBike.brand} {selectedBike.model}</h2>
                    <p className="text-gray-400">{selectedBike.year} · {selectedBike.color} · {selectedBike.plate}</p>
                  </div>
                  <Badge className="bg-moto-orange text-lg px-4 py-1">
                    {selectedBike.health}% Salud
                  </Badge>
                </div>
              </div>
            </div>
            
            <CardContent className="p-6">
              <Tabs defaultValue="services" className="w-full">
                <TabsList className="bg-moto-darker border-white/5 w-full mb-4">
                  <TabsTrigger value="services" className="flex-1 data-[state=active]:bg-moto-orange">Servicios</TabsTrigger>
                  <TabsTrigger value="history" className="flex-1 data-[state=active]:bg-moto-orange">Historial</TabsTrigger>
                  <TabsTrigger value="documents" className="flex-1 data-[state=active]:bg-moto-orange">Documentos</TabsTrigger>
                </TabsList>

                <TabsContent value="services" className="space-y-4">
                  {/* Next Service Alert */}
                  <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex items-center gap-4">
                    <AlertTriangle className="w-8 h-8 text-yellow-500" />
                    <div className="flex-1">
                      <p className="font-medium">Próximo servicio próximo</p>
                      <p className="text-sm text-gray-400">
                        Cambio de aceite en {selectedBike.nextService.km - selectedBike.mileage} km o {selectedBike.nextService.days} días
                      </p>
                    </div>
                    <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                      Agendar
                    </Button>
                  </div>

                  {/* Upcoming Services */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold">Servicios Pendientes</h3>
                      <Button size="sm" variant="outline" className="border-white/10">
                        <Plus className="w-4 h-4 mr-1" />
                        Agregar
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {selectedBike.upcomingServices.map((service) => (
                        <div key={service.id} className="flex items-center justify-between p-3 bg-moto-darker rounded-xl">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                              <Clock className="w-5 h-5 text-yellow-500" />
                            </div>
                            <div>
                              <p className="font-medium">{service.type}</p>
                              <p className="text-sm text-gray-400">
                                {service.dueKm.toLocaleString()} km · {service.dueDate}
                              </p>
                            </div>
                          </div>
                          <Button size="sm" variant="outline" className="border-white/10">
                            Completar
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="history" className="space-y-2">
                  {selectedBike.services.map((service) => (
                    <div key={service.id} className="flex items-center justify-between p-3 bg-moto-darker rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        </div>
                        <div>
                          <p className="font-medium">{service.type}</p>
                          <p className="text-sm text-gray-400">
                            {service.km.toLocaleString()} km · {service.date}
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-green-500/20 text-green-500">Completado</Badge>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="documents">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Card className="bg-moto-darker border-white/5 p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-moto-orange/20 flex items-center justify-center">
                          <FileText className="w-6 h-6 text-moto-orange" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">SOAT</p>
                          <p className="text-sm text-green-500">Vigente hasta 15/12/2025</p>
                        </div>
                      </div>
                    </Card>
                    <Card className="bg-moto-darker border-white/5 p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-moto-orange/20 flex items-center justify-center">
                          <FileText className="w-6 h-6 text-moto-orange" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Revisión Técnico-Mecánica</p>
                          <p className="text-sm text-green-500">Vigente hasta 20/08/2025</p>
                        </div>
                      </div>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Stats Sidebar */}
          <div className="space-y-4">
            {/* Mileage Card */}
            <Card className="bg-moto-gray border-white/5">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-moto-orange/20 flex items-center justify-center">
                    <Gauge className="w-6 h-6 text-moto-orange" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Kilometraje</p>
                    <p className="text-2xl font-bold">{selectedBike.mileage.toLocaleString()} km</p>
                  </div>
                </div>
                <Progress value={75} className="h-2" />
                <p className="text-xs text-gray-500 mt-2">75% hacia el próximo servicio</p>
              </CardContent>
            </Card>

            {/* Health Score */}
            <Card className="bg-moto-gray border-white/5">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-green-500" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Estado General</p>
                    <p className="text-2xl font-bold text-green-500">{selectedBike.health}%</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Motor</span>
                    <span className="text-green-500">95%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Frenos</span>
                    <span className="text-yellow-500">80%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Neumáticos</span>
                    <span className="text-green-500">90%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Cadena</span>
                    <span className="text-yellow-500">75%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-moto-gray border-white/5">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Acciones Rápidas</h3>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start border-white/10">
                    <Wrench className="w-4 h-4 mr-2" />
                    Registrar Servicio
                  </Button>
                  <Button variant="outline" className="w-full justify-start border-white/10">
                    <Camera className="w-4 h-4 mr-2" />
                    Agregar Foto
                  </Button>
                  <Button variant="outline" className="w-full justify-start border-white/10">
                    <FileText className="w-4 h-4 mr-2" />
                    Subir Documento
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Add Bike Dialog */}
      <Dialog open={showAddBike} onOpenChange={setShowAddBike}>
        <DialogContent className="bg-moto-gray border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Agregar Nueva Moto</DialogTitle>
            <DialogDescription className="text-gray-400">
              Ingresa los datos de tu moto para agregarla a tu garaje.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Marca</label>
                <input type="text" className="w-full bg-moto-darker border border-white/10 rounded-lg p-2 text-white" placeholder="Honda" />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Modelo</label>
                <input type="text" className="w-full bg-moto-darker border border-white/10 rounded-lg p-2 text-white" placeholder="CB500F" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Año</label>
                <input type="number" className="w-full bg-moto-darker border border-white/10 rounded-lg p-2 text-white" placeholder="2024" />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Placa</label>
                <input type="text" className="w-full bg-moto-darker border border-white/10 rounded-lg p-2 text-white" placeholder="ABC-123" />
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-400 mb-1 block">Kilometraje Actual</label>
              <input type="number" className="w-full bg-moto-darker border border-white/10 rounded-lg p-2 text-white" placeholder="0" />
            </div>
            <div>
              <label className="text-sm text-gray-400 mb-1 block">Color</label>
              <input type="text" className="w-full bg-moto-darker border border-white/10 rounded-lg p-2 text-white" placeholder="Rojo" />
            </div>
            <Button className="w-full bg-moto-orange hover:bg-moto-orange-dark">
              Agregar Moto
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
