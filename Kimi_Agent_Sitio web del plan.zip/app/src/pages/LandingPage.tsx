import { useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { 
  Menu, X, MapPin, Users, ShoppingBag, 
  Wrench, Route, Zap, ArrowRight
} from 'lucide-react'
import { Button } from '@/components/ui/button'

export function LandingPage() {
  const navigate = useNavigate()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const enterApp = () => {
    navigate('/app/home')
  }

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setIsMenuOpen(false)
    }
  }

  return (
    <div className="min-h-screen bg-moto-dark text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-moto-dark/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-moto-orange to-moto-orange-dark flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">Moteros<span className="text-moto-orange">Co</span></span>
            </div>
            
            <div className="hidden lg:flex items-center gap-8">
              <button onClick={() => scrollToSection('features')} className="text-sm text-gray-300 hover:text-white transition-colors">Características</button>
              <button onClick={() => scrollToSection('how-it-works')} className="text-sm text-gray-300 hover:text-white transition-colors">Cómo Funciona</button>
              <button onClick={() => scrollToSection('pricing')} className="text-sm text-gray-300 hover:text-white transition-colors">Planes</button>
              <button onClick={() => scrollToSection('community')} className="text-sm text-gray-300 hover:text-white transition-colors">Comunidad</button>
            </div>

            <div className="hidden lg:flex items-center gap-4">
              <Button variant="ghost" className="text-sm" onClick={enterApp}>
                Explorar App
              </Button>
              <Button 
                className="bg-moto-orange hover:bg-moto-orange-dark text-white text-sm"
                onClick={enterApp}
              >
                Entrar a la App
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            <button 
              className="lg:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden bg-moto-dark/95 backdrop-blur-xl border-t border-white/5">
            <div className="px-4 py-6 space-y-4">
              <button onClick={() => scrollToSection('features')} className="block w-full text-left py-2 text-gray-300">Características</button>
              <button onClick={() => scrollToSection('how-it-works')} className="block w-full text-left py-2 text-gray-300">Cómo Funciona</button>
              <button onClick={() => scrollToSection('pricing')} className="block w-full text-left py-2 text-gray-300">Planes</button>
              <button onClick={() => scrollToSection('community')} className="block w-full text-left py-2 text-gray-300">Comunidad</button>
              <div className="pt-4 space-y-3">
                <Button variant="outline" className="w-full" onClick={enterApp}>Explorar App</Button>
                <Button className="w-full bg-moto-orange hover:bg-moto-orange-dark" onClick={enterApp}>
                  Entrar a la App
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="/hero-motorcycle.jpg" 
            alt="Motorcycle on mountain road" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-moto-dark via-moto-dark/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-moto-dark via-transparent to-moto-dark/50" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-slide-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-moto-orange/20 border border-moto-orange/30">
                <span className="w-2 h-2 rounded-full bg-moto-orange animate-pulse" />
                <span className="text-sm text-moto-orange-light">App disponible ahora</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight">
                La red social para{' '}
                <span className="text-gradient">motociclistas</span>{' '}
                colombianos
              </h1>
              
              <p className="text-lg sm:text-xl text-gray-400 max-w-xl">
                Conecta con otros moteros, descubre rutas épicas, gestiona el mantenimiento de tu moto 
                y compra/vende en el marketplace especializado.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-moto-orange hover:bg-moto-orange-dark text-white px-8 animate-pulse-glow"
                  onClick={enterApp}
                >
                  <ArrowRight className="w-5 h-5 mr-2" />
                  Entrar a la App
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white/20 hover:bg-white/10"
                  onClick={() => scrollToSection('features')}
                >
                  Ver Características
                </Button>
              </div>

              <div className="flex items-center gap-8 pt-4">
                <div>
                  <div className="text-3xl font-bold text-moto-orange">9M+</div>
                  <div className="text-sm text-gray-500">Motos en Colombia</div>
                </div>
                <div className="w-px h-12 bg-white/10" />
                <div>
                  <div className="text-3xl font-bold text-moto-orange">50K+</div>
                  <div className="text-sm text-gray-500">Usuarios activos</div>
                </div>
                <div className="w-px h-12 bg-white/10" />
                <div>
                  <div className="text-3xl font-bold text-moto-orange">5★</div>
                  <div className="text-sm text-gray-500">Calificación</div>
                </div>
              </div>
            </div>

            <div className="hidden lg:block relative">
              <div className="relative animate-float">
                <img 
                  src="/app-mockup.jpg" 
                  alt="MoterosCo App" 
                  className="rounded-3xl shadow-2xl shadow-moto-orange/20"
                />
                <div className="absolute -bottom-6 -left-6 glass rounded-2xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-moto-orange flex items-center justify-center">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">+1,250 moteros</div>
                      <div className="text-xs text-gray-400">en línea ahora</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Preview */}
      <section id="features" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-moto-orange text-sm font-semibold uppercase tracking-wider">Características</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 mb-6">
              Todo lo que necesitas en <span className="text-gradient">una sola app</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Users, title: 'Red Social', desc: 'Conecta con moteros de tu ciudad', path: '/app/home' },
              { icon: Route, title: 'GPS & Rutas', desc: 'Navegación inteligente para motos', path: '/app/map' },
              { icon: Wrench, title: 'Hoja de Vida', desc: 'Gestiona el mantenimiento', path: '/app/my-bikes' },
              { icon: ShoppingBag, title: 'Marketplace', desc: 'Compra y vende motos y repuestos', path: '/app/marketplace' },
              { icon: MapPin, title: 'Explorar', desc: 'Descubre rutas de la comunidad', path: '/app/explore' },
              { icon: Users, title: 'Mensajes', desc: 'Chatea con otros moteros', path: '/app/messages' },
            ].map((feature, index) => (
              <button
                key={index}
                onClick={enterApp}
                className="group text-left p-6 rounded-2xl bg-moto-gray border border-white/5 hover:border-moto-orange/50 transition-all duration-300"
              >
                <div className="w-14 h-14 rounded-xl bg-moto-orange/20 flex items-center justify-center mb-4 group-hover:bg-moto-orange/30 transition-colors">
                  <feature.icon className="w-7 h-7 text-moto-orange" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.desc}</p>
                <div className="mt-4 flex items-center text-moto-orange text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Explorar</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-moto-orange/20 to-moto-orange-dark/20" />
        <div className="absolute inset-0 bg-moto-dark/80" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            ¿Listo para comenzar tu <span className="text-gradient">próxima aventura</span>?
          </h2>
          <p className="text-gray-400 text-lg mb-10 max-w-2xl mx-auto">
            Entra a MoterosCo ahora y únete a la comunidad de motociclistas más grande de Colombia.
          </p>
          
          <Button 
            size="lg" 
            className="bg-moto-orange hover:bg-moto-orange-dark text-white px-10 py-6 text-lg"
            onClick={enterApp}
          >
            <ArrowRight className="w-6 h-6 mr-2" />
            Entrar a la App Ahora
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-moto-darker border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-moto-orange flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold">Moteros<span className="text-moto-orange">Co</span></span>
            </div>
            <p className="text-gray-500 text-sm">
              © 2025 MoterosCo. Todos los derechos reservados.
            </p>
            <p className="text-gray-500 text-sm">
              Hecho con pasión en Colombia 🇨🇴
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
