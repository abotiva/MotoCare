import { Outlet, NavLink, useLocation } from 'react-router-dom'
import { 
  Home, Compass, Map as MapIcon, ShoppingBag, 
  MessageCircle, User, Bike, Settings, Zap, Bell, Search, Menu, X
} from 'lucide-react'
import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { InstallPrompt } from '@/components/InstallPrompt'

const navItems = [
  { path: '/app/home', icon: Home, label: 'Inicio' },
  { path: '/app/explore', icon: Compass, label: 'Explorar' },
  { path: '/app/map', icon: MapIcon, label: 'Mapa' },
  { path: '/app/marketplace', icon: ShoppingBag, label: 'Marketplace' },
  { path: '/app/messages', icon: MessageCircle, label: 'Mensajes' },
]

const sidebarItems = [
  { path: '/app/profile', icon: User, label: 'Mi Perfil' },
  { path: '/app/my-bikes', icon: Bike, label: 'Mis Motos' },
  { path: '/app/settings', icon: Settings, label: 'Configuración' },
]

export function MainLayout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const location = useLocation()

  return (
    <div className="min-h-screen bg-moto-dark text-white flex">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-moto-darker border-r border-white/5 fixed h-full">
        {/* Logo */}
        <div className="p-6 border-b border-white/5">
          <NavLink to="/app/home" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-moto-orange to-moto-orange-dark flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">Moteros<span className="text-moto-orange">Co</span></span>
          </NavLink>
        </div>

        {/* Main Navigation */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 px-3">
            Principal
          </div>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-moto-orange text-white'
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span className="flex-1">{item.label}</span>
              {item.path === '/app/messages' && (
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  3
                </span>
              )}
            </NavLink>
          ))}

          <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-6 mb-3 px-3">
            Personal
          </div>
          {sidebarItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-moto-orange text-white'
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* User Mini Profile */}
        <div className="p-4 border-t border-white/5">
          <NavLink to="/app/profile" className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=motero1" 
              alt="Profile" 
              className="w-10 h-10 rounded-full bg-moto-gray"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">Juan Pérez</p>
              <p className="text-xs text-gray-500">@juan_rider</p>
            </div>
          </NavLink>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-moto-dark/95 backdrop-blur-xl border-b border-white/5">
          <div className="flex items-center justify-between h-16 px-4 lg:px-6">
            {/* Mobile Logo */}
            <div className="lg:hidden flex items-center gap-3">
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-lg hover:bg-white/5"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              <NavLink to="/app/home" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-moto-orange flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold">Moteros<span className="text-moto-orange">Co</span></span>
              </NavLink>
            </div>

            {/* Page Title - Desktop */}
            <div className="hidden lg:block">
              <h1 className="text-xl font-semibold">
                {navItems.find(i => i.path === location.pathname)?.label || 
                 sidebarItems.find(i => i.path === location.pathname)?.label || 
                 'Inicio'}
              </h1>
            </div>

            {/* Search & Actions */}
            <div className="flex items-center gap-3">
              {showSearch ? (
                <div className="hidden sm:flex items-center gap-2">
                  <Input 
                    placeholder="Buscar..." 
                    className="w-64 bg-moto-darker border-white/10"
                    autoFocus
                  />
                  <button onClick={() => setShowSearch(false)} className="p-2 hover:bg-white/5 rounded-lg">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => setShowSearch(true)}
                  className="hidden sm:flex p-2 hover:bg-white/5 rounded-lg"
                >
                  <Search className="w-5 h-5 text-gray-400" />
                </button>
              )}
              
              <button className="relative p-2 hover:bg-white/5 rounded-lg">
                <Bell className="w-5 h-5 text-gray-400" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-moto-orange rounded-full" />
              </button>
              
              <NavLink to="/app/profile" className="lg:hidden">
                <img 
                  src="https://api.dicebear.com/7.x/avataaars/svg?seed=motero1" 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full bg-moto-gray"
                />
              </NavLink>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto">
          <Outlet />
        </div>

        {/* Bottom Navigation - Mobile */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-moto-darker border-t border-white/5 z-50">
          <div className="flex justify-around items-center h-16">
            {navItems.slice(0, 5).map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center flex-1 h-full ${
                    isActive ? 'text-moto-orange' : 'text-gray-400'
                  }`
                }
              >
                <div className="relative">
                  <item.icon className="w-6 h-6" />
                  {item.path === '/app/messages' && (
                    <span className="absolute -top-1 -right-2 bg-red-500 text-white text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full">
                      3
                    </span>
                  )}
                </div>
                <span className="text-[10px] mt-1">{item.label}</span>
              </NavLink>
            ))}
          </div>
        </nav>

        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-moto-dark">
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
              <span className="font-bold text-lg">Menú</span>
              <button onClick={() => setIsMobileMenuOpen(false)} className="p-2">
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="p-4 space-y-1">
              {[...navItems, ...sidebarItems].map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-4 px-4 py-4 rounded-xl ${
                      isActive
                        ? 'bg-moto-orange text-white'
                        : 'text-gray-400 hover:bg-white/5'
                    }`
                  }
                >
                  <item.icon className="w-6 h-6" />
                  <span className="text-lg">{item.label}</span>
                  {item.path === '/app/messages' && (
                    <span className="ml-auto bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-full">
                      3
                    </span>
                  )}
                </NavLink>
              ))}
            </nav>
          </div>
        )}
      </main>
      
      {/* PWA Install Prompt */}
      <InstallPrompt />
    </div>
  )
}
