import { useState, useEffect } from 'react'
import { Download, X, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showPrompt, setShowPrompt] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true)
      return
    }

    // Check if installed on iOS
    if ((window.navigator as any).standalone === true) {
      setIsInstalled(true)
      return
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      setShowPrompt(true)
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) {
      // For iOS, show instructions
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
      if (isIOS) {
        alert('Para instalar en iOS:\n\n1. Toca el botón Compartir (📤)\n2. Selecciona "Agregar a Inicio"\n3. Toca "Agregar"')
      }
      return
    }

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === 'accepted') {
      console.log('PWA instalada')
    }

    setDeferredPrompt(null)
    setShowPrompt(false)
  }

  if (isInstalled || !showPrompt) return null

  return (
    <div className="fixed bottom-20 lg:bottom-6 left-4 right-4 z-50 lg:left-auto lg:right-6 lg:w-96">
      <div className="bg-moto-gray border border-moto-orange/30 rounded-2xl shadow-xl shadow-moto-orange/10 p-4 animate-slide-up">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-moto-orange flex items-center justify-center flex-shrink-0">
            <Smartphone className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">Instalar MoterosCo</h3>
              <button 
                onClick={() => setShowPrompt(false)}
                className="p-1 hover:bg-white/5 rounded-lg transition-colors"
              >
                <X className="w-4 h-4 text-gray-400" />
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Instala la app para acceso rápido y notificaciones incluso sin conexión.
            </p>
            <div className="flex gap-2 mt-3">
              <Button 
                size="sm" 
                className="flex-1 bg-moto-orange hover:bg-moto-orange-dark text-xs"
                onClick={handleInstall}
              >
                <Download className="w-4 h-4 mr-1" />
                Instalar
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className="text-gray-400 text-xs"
                onClick={() => setShowPrompt(false)}
              >
                Ahora no
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
